#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "plcsim::plcsim_core" for configuration "Release"
set_property(TARGET plcsim::plcsim_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(plcsim::plcsim_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/plcsim_core.lib"
  )

list(APPEND _cmake_import_check_targets plcsim::plcsim_core )
list(APPEND _cmake_import_check_files_for_plcsim::plcsim_core "${_IMPORT_PREFIX}/lib/plcsim_core.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
